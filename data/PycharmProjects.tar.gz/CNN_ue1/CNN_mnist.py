import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Dense, Dropout, Flatten

### Vorbereitung Input ###

# Datensatz laden
(x_train, y_train), (x_test, y_test) = mnist.load_data()

print(x_train.shape, x_test.shape)

# Reshape data
img_rows, img_cols = 28, 28   # Bilder sind 28x28

x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)

# Konvertierung und Normalisierung
  # lernen funktioniert somit normalerweise schneller

  # Konvertierung in float32
x_train = x_train.astype('float32')
x_test = x_test.astype('float32')

x_train /= 255
x_test /= 255

### Vorbereitung Output ###
# Verwendung von keras.utils -> categorize -> um Anzahl der Klassen zu definieren, die ich brauche und Werte umzuwandeln
y_train = keras.utils.to_categorical(y_train, 10)
y_test = keras.utils.to_categorical(y_test, 10)


# Modell anlegen
model = Sequential()
  # Layer hinzufuegen
  # Convolutional Layer:
    # Aktivierungsfunktion -> eig immer ReLU -> bei neg. Werten = 0 (Sigmoid und Tangens hab ich immer nur Werte zw. 1 & -1
    # -> bei ReLU nicht -> Werte werden nicht gequetscht
    # wir haben 28x28 & 1 Kanal (Graustufen-Bilder)
model.add(Conv2D(64,(3,3), activation='relu', input_shape=(28,28,1)))

  # Maxpooling-Layer:
model.add(MaxPooling2D(pool_size=(2,2)))

  # Convolutional Layer
model.add(Conv2D(64,(3,3), activation='relu', input_shape=(28,28,1)))

  #  Maxpooling-Layer:
model.add(MaxPooling2D(pool_size=(2,2)))

  # Dropout Layer:
    # 25% der Layer sollen ausgeblendet werden
model.add(Dropout(0.25))

  # Full Connection Layer:
    # flachen Layer = flatten -> nimmt letzen Pooling layer her und die werden dann mit 1:1 Verfahren mit letztem Pooling Layer verbunden
model.add(Flatten())

  # MLP-Layer: (gehoert zum Full Connection Layer)
    # wichtig, das man MLP-Layer danach einbaut
model.add(Dense(128, activation='relu'))

  # Output-Layer von MLP:
    # hat 10 Klassen
model.add(Dense(10, activation='softmax'))

# Modell kompilieren
model.compile(loss=keras.losses.categorical_crossentropy, optimizer='adam', metrics=['accuracy'])

# Modell trainieren
model.fit(x_train, y_train, batch_size=128, epochs=10, verbose=1, validation_data=(x_test, y_test))

# Modell evaluieren
score = model.evaluate(x_test, y_test, verbose=0)

print('test error: ' + str(score[0]))
print('test accuracy: ' + str(score[1]))









