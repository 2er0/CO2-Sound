import glob
import random
import h5py
import numpy as np
import os
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation
from keras.optimizers import Adam
from keras.utils import np_utils
from keras import losses
from keras.callbacks import ModelCheckpoint
from sklearn import metrics

# initialize random generator
np.random.seed(1)

outfile = 'x_train_nlp.npy'
X = np.load(outfile)

outfile = 'y_train_nlp.npy'
y = np.load(outfile)

num_labels = y.shape[1]

num_cols = X.shape[1]



# build MLP model
neurons = 200
act_fun = 'relu'

model = Sequential()

# define input layer and first hidden layer with  neurons
model.add(Dense(neurons, input_shape=(num_cols,)))
model.add(Activation(act_fun))
model.add(Dropout(0.1))

# define second hidden layer with  neurons
model.add(Dense(neurons))
model.add(Activation(act_fun))
model.add(Dropout(0.1))

# define output layer
model.add(Dense(num_labels))
model.add(Activation('softmax'))
model.compile(loss='categorical_crossentropy', metrics=['accuracy'], optimizer='adam')

# save best model
filepath = "weights1.best.hdf5"
os.remove(filepath)
checkpoint = ModelCheckpoint(filepath, monitor='val_acc', verbose=1, save_best_only=True, mode='max')
callbacks_list = [checkpoint]

model.compile(loss='categorical_crossentropy', metrics=['accuracy'], optimizer='adam')
history = model.fit(X, y, batch_size=32, epochs=60, validation_split=0.15, callbacks=callbacks_list, verbose=0)

model.load_weights("weights1.best.hdf5")
# predict with trained MLP
scores = model.evaluate(X, y, verbose=0)
print("Genauigkeit Trainingsdaten und Validation %s: %.2f%%" % (model.metrics_names[1], scores[1] * 100))


# Test Data
outfile = 'x_test_nlp.npy'
X = np.load(outfile)
outfile = 'y_test_nlp.npy'
y = np.load(outfile)

# predict model with test data
scores = model.evaluate(X, y, verbose=0)
print("Genauigkeit Testdaten %s: %.2f%%" % (model.metrics_names[1], scores[1] * 100))


# plot history for accuracy
plt.figure(1)
plt.plot(history.history['acc'])
plt.plot(history.history['val_acc'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show(block=False)


# plot history for loss
plt.figure(2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()