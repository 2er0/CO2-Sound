import librosa as lb
import librosa.display as lbd
import numpy as np
import IPython.display as ipd
import os
import pandas as pd
import glob
import matplotlib.pyplot as plt
import random
import h5py
import sys
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation
from keras.optimizers import Adam
from keras.utils import np_utils
from keras import losses
from keras.callbacks import ModelCheckpoint
from sklearn import metrics
from sklearn.preprocessing import LabelEncoder

#ipd.Audio("../data/Train/2022.wav")
#data, sampling_rate = lb.load('../data/Train/2022.wav')

#plt.figure(figsize=(20, 4))
#lbd.waveplot(data, sr=sampling_rate)
#plt.show()

#root_dir = os.path.abspath('.')
data_dir = '/home/administrator/data/'

train = pd.read_csv(os.path.join(data_dir, 'Train', 'train_short.csv'))
test = pd.read_csv(os.path.join(data_dir, 'Test', 'test.csv'))


def parser(row,typ):


    # function to load files and extract features

        if typ == 0:
            file_name = os.path.join(os.path.abspath(data_dir), 'Train', str(row.ID) + '.wav')
        else:
            file_name = os.path.join(os.path.abspath(data_dir), 'Test', str(row.ID) + '.wav')
         # handle exception to check if there isn't a file which is corrupted
        try:
            # here kaiser_fast is a technique used for faster extraction
            print ('Processing file: ',file_name)
            X, sample_rate = lb.load(file_name, res_type='kaiser_fast')


            #extract features

            #stft = np.abs(lb.stft(X))
            #mfccs = np.mean(lb.feature.mfcc(y=X, sr=sample_rate, n_mfcc=40).T, axis=0)
            #chroma = np.mean(lb.feature.chroma_stft(S=stft, sr=sample_rate).T, axis=0)
            #mel = np.mean(lb.feature.melspectrogram(X, sr=sample_rate).T, axis=0)
            #contrast = np.mean(lb.feature.spectral_contrast(S=stft, sr=sample_rate).T, axis=0)
            #tonnetz = np.mean(lb.feature.tonnetz(y=lb.effects.harmonic(X), sr=sample_rate).T, axis=0)

            mfcc_abs= np.mean(lb.feature.mfcc(y=X, sr=sample_rate, n_mfcc=40).T, axis=0)
            mfcc_delta = lb.feature.delta(mfcc_abs)
            rms = np.mean(lb.feature.rmse(y=X).T, axis=0)

            feature= np.hstack([mfcc_abs, mfcc_delta, rms])
            label = row.Class

        except Exception as e:
            print("Error encountered while parsing file: ", file_name)
            sys.exit()



        return [feature, label]


temp = train.apply(parser, axis=1,typ=0)
temp.columns = ['feature', 'label']


X = np.array(temp.feature.tolist())
y = np.array(temp.label.tolist())


#########################################################
lab = LabelEncoder()
y = np_utils.to_categorical(lab.fit_transform(y))


num_labels = y.shape[1]
num_cols = X.shape[1]

outfile = 'x_train'
np.save(outfile, X)

outfile = 'y_train'
np.save(outfile, y)

# initialize random generator
np.random.seed(1)

# build MLP model
neurons= 210
act_fun='relu'
model = Sequential()

# define input layer and first hidden layer with  neurons
model.add(Dense(neurons, input_shape=(num_cols,)))
model.add(Activation(act_fun))
model.add(Dropout(0.1))

# define second hidden layer with  neurons
model.add(Dense(neurons))
model.add(Activation(act_fun))
model.add(Dropout(0.1))

# define output layer
model.add(Dense(num_labels))
model.add(Activation('softmax'))
model.compile(loss='categorical_crossentropy', metrics=['accuracy'], optimizer='adam')

#save best model
filepath="weights.best.hdf5"
checkpoint = ModelCheckpoint(filepath, monitor='val_acc', verbose=1, save_best_only=True, mode='max')
callbacks_list = [checkpoint]

#train MLP model
model.fit(X, y, batch_size=32, epochs=200, validation_split=0.15, callbacks=callbacks_list, verbose=0)

#predict with trained MLP
y_pred = model.predict(X)
ori = (np.argmax(y, axis=1))
net = (np.argmax(y_pred, axis=1))

sum=0
l = X.shape[0]

for x in range(0, l-1):
      if (ori[x] != net[x]):
           sum = sum+1







#Test Data

temp = test.apply(parser, axis=1, typ=1)
temp.columns = ['feature', 'label']

X = np.array(temp.feature.tolist())
y = np.array(temp.label.tolist())
y = np_utils.to_categorical(lab.fit_transform(y))

outfile = 'x_test'
np.save(outfile, X)

outfile = 'y_test'
np.save(outfile, y)


#predict model with test data
y_pred= model.predict(X)
ori = (np.argmax(y, axis=1))
net = (np.argmax(y_pred,axis=1))

print ("---  Anzahl der Fehler alle Trainingsdaten (inkl. Validation): ", sum, " von ", l)

sum=0
l = X.shape[0]

for x in range(0, l-1):
        if (ori[x] != net[x]):
            sum = sum+1

print ("---  Anzahl der Fehler in Testdaten: ", sum," von ", l)

outfile = 'x_test.npy'
Xn=np.load(outfile)
Xn == x

outfile = 'y_test.npy'
yn=np.load(outfile)
y == yn