import numpy as np
import IPython.display as ipd
import os
import pandas as pd
import matplotlib.pyplot as plt
import random
import h5py
import sys
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Conv2D, Flatten, MaxPooling2D
from keras.optimizers import Adam
from keras.utils import np_utils
from keras import losses
from sklearn import metrics
from keras.callbacks import ModelCheckpoint

#

np.random.seed(5)

outfile = 'x_train_cnn.npy'
X = np.load(outfile)
outfile = 'y_train_cnn.npy'
y = np.load(outfile)

filepath = "weights.cnn.best.hdf5"
#os.remove(filepath)
checkpoint = ModelCheckpoint(filepath, monitor='val_acc', verbose=1, save_best_only=True, mode='max')
callbacks_list = [checkpoint]

model = Sequential()
model.add(Conv2D(12, kernel_size=3, strides=[2, 2],
                 activation='relu',
                 input_shape=(60, 41, 2)))
model.add(MaxPooling2D(pool_size=(4, 2)))

model.add(Conv2D(24, kernel_size=3, strides=[2, 2],
                 activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Flatten())
model.add(Dense(400, activation='relu'))
model.add(Dense(10, activation='softmax'))


model.compile(loss='categorical_crossentropy', # using the cross-entropy loss function
              optimizer='adam', # using the Adam optimiser
              metrics=['accuracy']) # reporting the accuracy


history = model.fit(X, y,                # Train
                    #  the model using the training set...
          batch_size=30, epochs=30,
          verbose=1, validation_split=0.15, callbacks=callbacks_list)  # 15% of the data for validation


model.load_weights("weights.cnn.best.hdf5")

#predict with trained CNN

scores = model.evaluate(X, y, verbose=0)
print("Genauigkeit Trainingsdaten und Validation %s: %.2f%%" % (model.metrics_names[1], scores[1] * 100))


# Load preared Test Data
outfile = 'x_test_cnn.npy'
X = np.load(outfile)
outfile = 'y_test_cnn.npy'
y = np.load(outfile)


#predict model with test data
scores = model.evaluate(X, y, verbose=0)
print("Genauigkeit Testdaten %s: %.2f%%" % (model.metrics_names[1], scores[1] * 100))

#model.save('cnn_model.h5')
#model = load_model('cnn_model.h5')

# plot history for accuracy
plt.figure(1)
plt.plot(history.history['acc'])
plt.plot(history.history['val_acc'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show(block=False)


# plot history for loss
plt.figure(2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()