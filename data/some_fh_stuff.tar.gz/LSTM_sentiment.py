
from __future__ import print_function
import os
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Embedding
from keras.layers import LSTM
from keras.datasets import imdb
import numpy as np
import matplotlib.pyplot as plt

max_features = 10000 #20000
maxlen = 50  # cut texts after this number of words (among top max_features most common words)
batch_size = 50

print('Loading imdb data...')
(x_train, y_train), (x_test, y_test) = imdb.load_data(path="imdb.npz", num_words=max_features)


print(len(x_train), 'train sequences')
print(len(x_test), 'test sequences')

print('Pad sequences (samples x time)')
x_train = sequence.pad_sequences(x_train, maxlen=maxlen, padding='post')
x_test = sequence.pad_sequences(x_test, maxlen=maxlen, padding='post')

print('x_train shape:', x_train.shape)
print('x_test shape:', x_test.shape)


print('Build model...')

model = Sequential()
model.add(Embedding(max_features, 128))
model.add(LSTM(128, dropout=0.2, recurrent_dropout=0.2))
model.add(Dense(1, activation='sigmoid'))


model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
#show model
print(model.summary())


print('Train...')

history=model.fit(x_train, y_train,
          batch_size=batch_size,
          epochs=3,
          validation_split=0.15, verbose=1)


print('Evaluate...')


scores = model.evaluate(x_test, y_test, verbose=0)
print("Accuracy: %.2f%%" % (scores[1]*100))

#plot history for accuracy
plt.figure(1)
plt.plot(history.history['acc'])
plt.plot(history.history['val_acc'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show(block=False)


# plot history for loss
plt.figure(2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.show()