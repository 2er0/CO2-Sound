import librosa
import librosa as lb
import librosa.display as lbd
import numpy as np
import IPython.display as ipd
import os
import pandas as pd
import glob
import matplotlib.pyplot as plt
import random
import h5py
import sys
from sklearn import metrics
from sklearn.preprocessing import LabelEncoder
from keras.utils import np_utils

#ipd.Audio("../data/Train/2022.wav")
#data, sampling_rate = lb.load('../data/Train/2022.wav')

#plt.figure(figsize=(20, 4))
#lbd.waveplot(data, sr=sampling_rate)
#plt.show()

#root_dir = os.path.abspath('.')


data_dir = '/home/administrator/data/'


#Function to extract feautures

def extract_features(typ):

    all_features = np.empty((0, 193))
    labels = []

    if typ == 0:
        train = pd.read_csv(os.path.join(data_dir, 'Train', 'train_short.csv'))

    else:
        train = pd.read_csv(os.path.join(data_dir, 'Train', 'test.csv'))

    dist = train.Class.value_counts()
    print (dist)

        # load files and extract features

    for row in train.itertuples():

        try:
            # here kaiser_fast is a technique used for faster extraction

            file_name = os.path.join(os.path.abspath(data_dir), 'Train', str((row.ID)) + '.wav')
            print ('Processing file: ', file_name)

            X, sample_rate = librosa.load(file_name,res_type='kaiser_fast')

            stft = np.abs(librosa.stft(X))
            mfccs = np.mean(librosa.feature.mfcc(y=X, sr=sample_rate, n_mfcc=40).T, axis=0)
            print(mfccs)
            #chroma = np.mean(librosa.feature.chroma_stft(S=stft, sr=sample_rate).T, axis=0)
            #mel = np.mean(librosa.feature.melspectrogram(X, sr=sample_rate).T, axis=0)
            #contrast = np.mean(librosa.feature.spectral_contrast(S=stft, sr=sample_rate).T, axis=0)
            #tonnetz = np.mean(librosa.feature.tonnetz(y=librosa.effects.harmonic(X), sr=sample_rate).T, axis=0)

            #features = np.hstack([mfccs, chroma, mel, contrast, tonnetz])

            #all_features = np.vstack([all_features, features])

            label = row.Class
            labels.append(label)

        except Exception as e:
            print("Error encountered while processing file: ", file_name)
            #sys.exit()

    return [np.array(all_features), np.array(labels)]


# get training data
[X, y] = extract_features(0)

# one-hot encode labels
lab = LabelEncoder()
y = np_utils.to_categorical(lab.fit_transform(y))

# save training set
outfile = 'x_train_nlp'
np.save(outfile, X)

outfile = 'y_train_nlp'
np.save(outfile, y)

# get test data
[X, y] = extract_features(1)
y = np_utils.to_categorical(lab.fit_transform(y))

# save test set
outfile = 'x_test_nlp'
np.save(outfile, X)

outfile = 'y_test_nlp'
np.save(outfile, y)
