import librosa as lb
import librosa.display as lbd
import numpy as np
import IPython.display as ipd
import os
import pandas as pd
import glob
import matplotlib.pyplot as plt
import random
import h5py
import sys
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation,Conv2D, Flatten, MaxPooling2D
from keras.optimizers import Adam
from keras.utils import np_utils
from keras import losses
from keras.callbacks import ModelCheckpoint
from sklearn import metrics
from sklearn.preprocessing import LabelEncoder


data_dir = '/home/administrator/data/'


def windows(data, window_size):
    start = 0
    while start < len(data):
        yield start, start + window_size
        start += (window_size / 2)

def extract_features(typ):
        frames = 41
        window_size = 512 * (frames - 1)
        bands = 60
        log_specgrams = []
        labels = []

        if (typ == 0):
            train = pd.read_csv(os.path.join(data_dir, 'Train', 'train_long.csv'))

        else:
            train = pd.read_csv(os.path.join(data_dir, 'Train', 'test.csv'))



    # function to load files and extract features

        for row in train.itertuples():

            try:
                # here kaiser_fast is a technique used for faster extraction

                file_name = os.path.join(os.path.abspath(data_dir), 'Train', str((row.ID)) + '.wav')
                print ('Processing file: ',file_name)
                sound_clip, s = lb.load(file_name, res_type='kaiser_fast')


                for (start, end) in windows(sound_clip, window_size):
                                if (len(sound_clip[start:end]) == window_size):
                                    signal = sound_clip[start:end]
                                    melspec = lb.feature.melspectrogram(signal, n_mels=bands)
                                    logspec = lb.logamplitude(melspec)
                                    logspec = logspec.T.flatten()[:, np.newaxis].T

                                    log_specgrams.append(logspec)
                                    label = row.Class
                                    labels.append(label)


            except Exception as e:
               print("Error encountered while processing file: ", file_name)
               sys.exit()


        log_specgrams = np.asarray(log_specgrams).reshape(len(log_specgrams), bands, frames, 1)
        features = np.concatenate((log_specgrams, np.zeros(np.shape(log_specgrams))), axis=3)

        for i in range(len(features)):
            features[i, :, :, 1] = lb.feature.delta(features[i, :, :, 0])

        return [features, labels]


[features, labels] = extract_features(0)

X = features
y = labels
lab = LabelEncoder()
y = np_utils.to_categorical(lab.fit_transform(y))



outfile = 'x_train_cnn'
np.save(outfile, X)

outfile = 'y_train_cnn'
np.save(outfile, y)


[features, labels] = extract_features(1)

X = features
y = labels
lab = LabelEncoder()
y = np_utils.to_categorical(lab.fit_transform(y))

outfile = 'x_test_cnn'
np.save(outfile, X)

outfile = 'y_test_cnn'
np.save(outfile, y)
