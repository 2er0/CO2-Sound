import os
print os.getcwd()
import pandas
import numpy
import matplotlib.pyplot as plt
import math
from sklearn.metrics import mean_squared_error


train = pandas.read_csv('~/my/X.xls')
print train.head()
print train.shape

test = pandas.read_csv('~/my/T.xls')
print test.head()
print test.shape