from keras.preprocessing.text import one_hot
from keras.preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Flatten
from keras.layers import LSTM
from keras.layers.embeddings import Embedding
from keras import backend as K
from numpy import random

# define corpus

docs = ['Well done',
		'Good work',
		'Great effort',
		'nice work',
		'Excellent',
		'Weak',
		'poor result',
		'not good',
		'poor work',
		'Could have done better']

# define test corpus
doc_test = ['effort poor',
			'great result']

random.seed(0)

# define class labels
labels = [1,1,1,1,1,0,0,0,0,0]
# integer encode the documents

# define size of vocabulary
vocab_size = 50

# Integer encode documents
encoded_docs = [one_hot(d, vocab_size) for d in docs]

print ('\n')
print ('Integer encoded documents:')
print(encoded_docs)


# pad integer encoded documents to a max length of 4 words
max_length = 4
padded_docs = pad_sequences(encoded_docs, maxlen=max_length, padding='post')
print ('Integer encoded and padded documents:')
print(padded_docs)


# define the model
model = Sequential()
model.add(Embedding(vocab_size, 8, input_length=max_length))
model.add(LSTM(8))
model.add(Dense(1, activation='sigmoid'))


# compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['acc'])

# print the model
print(model.summary())

# Train the model
model.fit(padded_docs, labels, epochs=150, verbose=0)


emmbedding_layer_output = K.function([model.layers[0].input], [model.layers[0].output])

layer_output = emmbedding_layer_output([padded_docs])[0]
print ('\n')
print ('Vector representation embedding layer for word: Well ')
print (layer_output[0])
print (layer_output[1])
print (layer_output[2])
# evaluate the model
loss, accuracy = model.evaluate(padded_docs, labels, verbose=0)
print('\n')
print('Accuracy of model after training: %f' % (accuracy*100))



# Test Model
encoded_doc_test = [one_hot(d, vocab_size) for d in doc_test]

# pad documents to a max length of 4 words
padded_doc_test = pad_sequences(encoded_doc_test, maxlen=max_length, padding='post')



print('\n')
print ('Prediction for :')
print(doc_test)


print('\n')
print('encoded sequence: ')
print (encoded_doc_test)


print('\n')
print('encoded and padded sequence: ')
print(padded_doc_test)

result = model.predict_classes(padded_doc_test, batch_size=None, verbose=0)
print('\n')
print('Result Class Prediction: ')
print(result)