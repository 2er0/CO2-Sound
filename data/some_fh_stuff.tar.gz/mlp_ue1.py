import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Dense, Dropout, Flatten

### Vorbereitung Input ###

# Datensatz laden
(x_train, y_train), (x_test, y_test) = mnist.load_data()

# Konvertieren und normalisieren
x_train = x_train.reshape(60000, 784)   # 60.000 Trainingsdaten, 784 Einheiten langer Vektor (28x28)
x_test = x_test.reshape(10000, 784)     # 10.000 Trainingsdaten, 784 Einheiten langer Vektor (28x28)

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')

x_train /= 255
x_test /= 255

### Vorbereitung Output ###
y_train = keras.utils.to_categorical(y_train, 10)
y_test = keras.utils.to_categorical(y_test, 10)

# Modell anlegen
model = Sequential()
  # 1. Layer = Dense-Layer mit 500 Neuronen, Akt.-Funkt. = Sigmoid -> diesmal kein Convolutional Layer, weil wir MLP bauen
model.add(Dense(500, activation='sigmoid', input_shape=(784,)))
model.add(Dropout(0.2))
model.add(Dense(512, activation='sigmoid'))
model.add(Dropout(0.2))
model.add(Dense(10, activation='softmax'))

# Modell kompilieren
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# Modell trainieren
model.fit(x_train, y_train, batch_size=246, epochs=10, verbose=1, validation_data=(x_test, y_test))

# Modell evaluation
score = model.evaluate(x_test, x_train, verbose = 0)

print('test error: ' + str(score[0]))
print('test accuracy: ' + str(score[1]))
