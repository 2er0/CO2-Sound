import librosa as lb
import librosa.display as lbd
import numpy as np
import IPython.display as ipd
import os
import pandas as pd
import glob
import matplotlib.pyplot as plt
import random
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten

from keras.optimizers import Adam
from keras.utils import np_utils
from sklearn import metrics
from sklearn.preprocessing import LabelEncoder

root_dir = os.path.abspath('.')
data_dir = '/home/administrator/data/'
train = pd.read_csv(os.path.join(data_dir, 'Train', 'train.csv'))
test = pd.read_csv(os.path.join(data_dir, 'Test', 'test.csv'))
f = open('/home/administrator/data/Train/train_neu.csv', 'w')

f.write('ID,Class \n')

for index, row in train.iterrows():
    file_name = os.path.join(os.path.abspath(data_dir), 'Train', str(row.ID) + '.wav')
    try:
        X, sample_rate = lb.load(file_name, res_type='kaiser_fast')
        f.write(str(row.ID)+ ','+ row.Class + '\n')

    except Exception as e:
        print ('error reading file: ', file_name)